Local NW origin; +X east,+Z south. Civil Y0=future surface S. World anchor, S and rotation unassigned.
Use these native layers only with this revision. Ordinary block and partial-host counts differ.
