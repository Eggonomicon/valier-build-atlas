# Supplied facings

Open promenade-kit/index.html for the catalog, canonical layer guides and assembly render. Each part below has three additional quarter-turn orientations. Their exact minimum, opening axes and materials are listed in their own placement files.

## CP01 · Planted diagonal facade bay

- [CP01-R1](promenade-kit/parts/CP01-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP01-R2](promenade-kit/parts/CP01-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP01-R3](promenade-kit/parts/CP01-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP02 · Slim promenade lantern

- [CP02-R1](promenade-kit/parts/CP02-R1/BUILD.md) · clipboard minimum [0, -1, 0]
- [CP02-R2](promenade-kit/parts/CP02-R2/BUILD.md) · clipboard minimum [0, -1, 0]
- [CP02-R3](promenade-kit/parts/CP02-R3/BUILD.md) · clipboard minimum [0, -1, 0]

## CP03 · Faceted canyon road portal

- [CP03-R1](promenade-kit/parts/CP03-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP03-R2](promenade-kit/parts/CP03-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP03-R3](promenade-kit/parts/CP03-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP04 · Glazed crossing span

- [CP04-R1](promenade-kit/parts/CP04-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP04-R2](promenade-kit/parts/CP04-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP04-R3](promenade-kit/parts/CP04-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP05 · Straight cliff avenue

- [CP05-R1](promenade-kit/parts/CP05-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP05-R2](promenade-kit/parts/CP05-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP05-R3](promenade-kit/parts/CP05-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP06 · Faceted avenue bend

- [CP06-R1](promenade-kit/parts/CP06-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP06-R2](promenade-kit/parts/CP06-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP06-R3](promenade-kit/parts/CP06-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP07 · Open-rail river promenade

- [CP07-R1](promenade-kit/parts/CP07-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP07-R2](promenade-kit/parts/CP07-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP07-R3](promenade-kit/parts/CP07-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP08 · Planted pocket court

- [CP08-R1](promenade-kit/parts/CP08-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP08-R2](promenade-kit/parts/CP08-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP08-R3](promenade-kit/parts/CP08-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP09 · Lined river reach

- [CP09-R1](promenade-kit/parts/CP09-R1/BUILD.md) · clipboard minimum [0, -5, 0]
- [CP09-R2](promenade-kit/parts/CP09-R2/BUILD.md) · clipboard minimum [0, -5, 0]
- [CP09-R3](promenade-kit/parts/CP09-R3/BUILD.md) · clipboard minimum [0, -5, 0]

## CP10 · Flared bridge bearing

- [CP10-R1](promenade-kit/parts/CP10-R1/BUILD.md) · clipboard minimum [0, -15, 0]
- [CP10-R2](promenade-kit/parts/CP10-R2/BUILD.md) · clipboard minimum [0, -15, 0]
- [CP10-R3](promenade-kit/parts/CP10-R3/BUILD.md) · clipboard minimum [0, -15, 0]

## CP11 · Faceted promenade bend

- [CP11-R1](promenade-kit/parts/CP11-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP11-R2](promenade-kit/parts/CP11-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP11-R3](promenade-kit/parts/CP11-R3/BUILD.md) · clipboard minimum [0, -2, 0]

## CP12 · Terrace stair

- [CP12-R1](promenade-kit/parts/CP12-R1/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP12-R2](promenade-kit/parts/CP12-R2/BUILD.md) · clipboard minimum [0, -2, 0]
- [CP12-R3](promenade-kit/parts/CP12-R3/BUILD.md) · clipboard minimum [0, -2, 0]
