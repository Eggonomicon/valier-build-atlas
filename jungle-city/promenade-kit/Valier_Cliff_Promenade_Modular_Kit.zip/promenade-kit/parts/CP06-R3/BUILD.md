# CP06-R3 · Faceted avenue bend · quarter-turn 3



Local +X is east and +Z is south. Heights are relative to the piece origin. The walk of a level piece is Y0. A port lists X along a north or south face and Z along an east or west face.

| Opening | Face | Along | Walking Y |
| --- | --- | --- | --- |
| Road | E | 0–11 | 0 |
| Road | W | 4–15 | 0 |

Choose a world position for local (0,0,0). Add **(0, -2, 0)** to that position for the clipboard minimum. The occupied source coordinates end at **(19, -1, 15)** inclusive. Both WorldEdit origin and offset are zero.



- Uses the same block counts as CP06. The placement and connector coordinates below apply to this supplied orientation.

Open `index.html` for level grids and `coordinates.csv.gz` for precise hosts. The grid keys give material metadata, shaped-block facing and multipart slots. Stock counts placed blocks and separate cut parts. Fill any marked sources by hand after closing the bank. Use the matching facing file in Schematica with Printer OFF for manual placement.
