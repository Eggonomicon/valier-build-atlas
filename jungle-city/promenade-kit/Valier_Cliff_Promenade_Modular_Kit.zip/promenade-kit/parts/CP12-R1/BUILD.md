# CP12-R1 · Terrace stair · quarter-turn 1



Local +X is east and +Z is south. Heights are relative to the piece origin. The walk of a level piece is Y0. A port lists X along a north or south face and Z along an east or west face.

| Opening | Face | Along | Walking Y |
| --- | --- | --- | --- |
| Upper landing | W | 1–6 | 6 |
| Lower landing | E | 1–6 | 0 |

Choose a world position for local (0,0,0). Add **(0, -2, 0)** to that position for the clipboard minimum. The occupied source coordinates end at **(15, 7, 7)** inclusive. Both WorldEdit origin and offset are zero.



- Uses the same block counts as CP12. The placement and connector coordinates below apply to this supplied orientation.

Open `index.html` for level grids and `coordinates.csv.gz` for precise hosts. The grid keys give material metadata, shaped-block facing and multipart slots. Stock counts placed blocks and separate cut parts. Fill any marked sources by hand after closing the bank. Use the matching facing file in Schematica with Printer OFF for manual placement.
