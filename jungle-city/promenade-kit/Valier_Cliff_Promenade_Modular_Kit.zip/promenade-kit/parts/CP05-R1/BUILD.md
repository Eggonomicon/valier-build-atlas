# CP05-R1 · Straight cliff avenue · quarter-turn 1



Local +X is east and +Z is south. Heights are relative to the piece origin. The walk of a level piece is Y0. A port lists X along a north or south face and Z along an east or west face.

| Opening | Face | Along | Walking Y |
| --- | --- | --- | --- |
| Road | W | 0–11 | 0 |
| Road | E | 0–11 | 0 |
| Hall sidewalk | S | 0–15 | 0 |
| River sidewalk | N | 0–15 | 0 |

Choose a world position for local (0,0,0). Add **(0, -2, 0)** to that position for the clipboard minimum. The occupied source coordinates end at **(15, -1, 11)** inclusive. Both WorldEdit origin and offset are zero.



- Uses the same block counts as CP05. The placement and connector coordinates below apply to this supplied orientation.

Open `index.html` for level grids and `coordinates.csv.gz` for precise hosts. The grid keys give material metadata, shaped-block facing and multipart slots. Stock counts placed blocks and separate cut parts. Fill any marked sources by hand after closing the bank. Use the matching facing file in Schematica with Printer OFF for manual placement.
