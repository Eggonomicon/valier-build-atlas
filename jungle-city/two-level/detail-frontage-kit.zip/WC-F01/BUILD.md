# WC-F01 · Planted canyon arcade

A 16-block-pitch cliff-front bay with double-height glazing, fine mullion lattice, planted mid-sill, shaped knees and a four-wide entry.

Local +X is east and +Z is south. Heights are relative to the piece origin. The walk of a level piece is Y0. A port lists X along a north or south face and Z along an east or west face.

| Opening | Face | Along | Walking Y |
| --- | --- | --- | --- |
| Promenade threshold | E | 6–9 | 0 |
| Workroom threshold | W | 6–9 | 0 |

Choose a world position for local (0,0,0). Add **(0, -2, 0)** to that position for the clipboard minimum. The occupied source coordinates end at **(16, 23, 15)** inclusive. Both WorldEdit origin and offset are zero.



- Set the east face beside the promenade at local Y0. Keep the Z6–9 doorway and access aisle clear.
- Repeat along Z at a pitch of 16. Frame the adjoining workroom from its own lower-level model.
- The dry model contains the facade, thresholds and trim. Use the separate city register for wall location and crew routes.
- Use a supplied facing file to preserve shape orientation and place parts manually with Schematica Printer OFF.



Open `index.html` for level grids and `coordinates.csv.gz` for precise hosts. The grid keys give material metadata, shaped-block facing and multipart slots. Stock counts placed blocks and separate cut parts. Fill any marked sources by hand after closing the bank. Use the matching facing file in Schematica with Printer OFF for manual placement.
